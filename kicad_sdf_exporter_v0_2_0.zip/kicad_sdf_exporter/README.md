# KiCad SDF Exporter

KiCad SDF Exporter converts a KiCad schematic into a normalized design package for
AI schematic training.

It exports:

- `schematic.sdf` - compact renderable schematic description
- `components.json` - component, symbol, pin, footprint, and placement data
- `nets.json` - resolved nets and pin memberships
- `bom.json` - BOM-oriented component rows
- `blocks.json` - inferred reusable functional circuit patterns
- `metadata.json` - export version, source file, units, and warnings
- `design_package.json` - one combined file for model training

The first version is intentionally file-based: it parses `.kicad_sch` directly, so
it can be used from KiCad scripting or from the command line.

## Usage

```powershell
python -m kicad_sdf_exporter.cli path\to\project.kicad_sch -o exported_design
```

The output folder will contain the normalized training package.

## Current scope

This exporter handles:

- schematic symbols, references, values, footprints, positions, rotations
- local library symbol pins when present in the schematic file
- physical wire connectivity
- local, global, and hierarchical labels
- same-name label net merging
- power symbols as named net anchors instead of BOM components
- BOM rows from exported components
- training-data warnings for weak or suspicious named nets
- inferred blocks such as power distribution, pullups, decoupling, interfaces,
  connectors, microcontrollers, sensors, and ICs

It is designed as a dataset factory, not as a PCB manufacturing signoff tool.

## Training-data notes

The exporter intentionally filters out meaningless one-pin anonymous nets. Named
nets are kept because they carry design intent. If a repeated named label only
resolves to one component pin, or a name like `SDA`/`SCL` does not reach a
matching pin, the exporter records a warning in `metadata.json`.

`blocks.json` is the abstraction layer intended to help models learn reusable
electronics patterns. For example, a drone flight controller and a macropad both
share patterns such as MCU core, power distribution, connectors, pullups,
decoupling capacitors, and digital interfaces, even though the final products are
different.

Each block includes a `quality` field. Blocks with related schematic warnings are
marked `use_for_training: false`, so you can still inspect them while keeping a
clean training subset.
