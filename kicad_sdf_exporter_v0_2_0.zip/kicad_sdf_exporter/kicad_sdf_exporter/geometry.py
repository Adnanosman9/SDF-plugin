from __future__ import annotations

import math


def rotate_point(x: float, y: float, degrees: float) -> tuple[float, float]:
    rad = math.radians(degrees)
    cos_a = math.cos(rad)
    sin_a = math.sin(rad)
    return x * cos_a - y * sin_a, x * sin_a + y * cos_a


def pin_side(rotation: float) -> str:
    angle = round(rotation % 360)
    if angle in (0, 360):
        return "left"
    if angle == 180:
        return "right"
    if angle == 90:
        return "bottom"
    if angle == 270:
        return "top"
    if 45 <= angle < 135:
        return "bottom"
    if 135 <= angle < 225:
        return "right"
    if 225 <= angle < 315:
        return "top"
    return "left"


def pin_tip(local_x: float, local_y: float, rotation: float, length: float) -> tuple[float, float]:
    side = pin_side(rotation)
    if side == "left":
        return local_x - length, local_y
    if side == "right":
        return local_x + length, local_y
    if side == "top":
        return local_x, local_y - length
    return local_x, local_y + length


def key(point: tuple[float, float], tolerance: float = 0.05) -> tuple[int, int]:
    return round(point[0] / tolerance), round(point[1] / tolerance)

