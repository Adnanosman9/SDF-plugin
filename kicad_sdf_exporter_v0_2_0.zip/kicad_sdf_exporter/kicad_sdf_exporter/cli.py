from __future__ import annotations

import argparse
from pathlib import Path

from .exporters import write_design_package
from .nets import resolve_nets
from .parser import parse_kicad_schematic


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Export KiCad .kicad_sch to SDF/JSON training package")
    parser.add_argument("schematic", help="Path to .kicad_sch file")
    parser.add_argument("-o", "--out", default="sdf_export", help="Output directory")
    parser.add_argument("--tolerance", type=float, default=0.05, help="Coordinate snap tolerance in millimeters")
    args = parser.parse_args(argv)

    schematic = Path(args.schematic)
    if not schematic.exists():
        parser.error(f"schematic not found: {schematic}")

    design = parse_kicad_schematic(schematic)
    resolve_nets(design, tolerance=args.tolerance)
    files = write_design_package(design, args.out)

    print(f"Exported {len(design.components)} components, {len(design.nets)} nets")
    for name, path in files.items():
        print(f"{name}: {path}")
    if design.warnings:
        print("Warnings:")
        for warning in design.warnings:
            print(f"- {warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

