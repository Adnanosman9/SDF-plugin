from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator, List, Union

Atom = Union[str, float, int]
SExpr = List[Union["SExpr", Atom]]


@dataclass(frozen=True)
class Token:
    value: str
    line: int
    col: int


def tokenize(text: str) -> Iterator[Token]:
    i = 0
    line = 1
    col = 1
    n = len(text)
    while i < n:
        ch = text[i]
        if ch in " \t\r\n":
            if ch == "\n":
                line += 1
                col = 1
            else:
                col += 1
            i += 1
            continue
        if ch == ";":
            while i < n and text[i] != "\n":
                i += 1
                col += 1
            continue
        if ch in "()":
            yield Token(ch, line, col)
            i += 1
            col += 1
            continue
        if ch == '"':
            start_line = line
            start_col = col
            i += 1
            col += 1
            out = []
            while i < n:
                ch = text[i]
                if ch == "\\" and i + 1 < n:
                    nxt = text[i + 1]
                    escapes = {"n": "\n", "t": "\t", "r": "\r", '"': '"', "\\": "\\"}
                    out.append(escapes.get(nxt, nxt))
                    i += 2
                    col += 2
                    continue
                if ch == '"':
                    i += 1
                    col += 1
                    break
                out.append(ch)
                if ch == "\n":
                    line += 1
                    col = 1
                else:
                    col += 1
                i += 1
            yield Token("".join(out), start_line, start_col)
            continue
        start = i
        start_col = col
        while i < n and text[i] not in " \t\r\n();":
            i += 1
            col += 1
        yield Token(text[start:i], line, start_col)


def parse(text: str) -> SExpr:
    tokens = list(tokenize(text))
    index = 0

    def parse_one() -> Union[SExpr, Atom]:
        nonlocal index
        if index >= len(tokens):
            raise ValueError("Unexpected end of S-expression")
        tok = tokens[index]
        index += 1
        if tok.value == "(":
            items: SExpr = []
            while index < len(tokens) and tokens[index].value != ")":
                items.append(parse_one())
            if index >= len(tokens):
                raise ValueError(f"Unclosed list starting near line {tok.line}")
            index += 1
            return items
        if tok.value == ")":
            raise ValueError(f"Unexpected ')' at line {tok.line}, column {tok.col}")
        return atom(tok.value)

    roots: SExpr = []
    while index < len(tokens):
        roots.append(parse_one())
    if len(roots) == 1 and isinstance(roots[0], list):
        return roots[0]
    return roots


def atom(value: str) -> Atom:
    try:
        if any(c in value for c in ".eE"):
            return float(value)
        return int(value)
    except ValueError:
        return value


def head(expr: object) -> str | None:
    if isinstance(expr, list) and expr and isinstance(expr[0], str):
        return expr[0]
    return None


def children(expr: SExpr, name: str) -> list[SExpr]:
    return [item for item in expr if isinstance(item, list) and head(item) == name]


def child(expr: SExpr, name: str) -> SExpr | None:
    for item in expr:
        if isinstance(item, list) and head(item) == name:
            return item
    return None


def value_after(expr: SExpr, name: str, default: object = None) -> object:
    item = child(expr, name)
    if item is None or len(item) < 2:
        return default
    return item[1]

