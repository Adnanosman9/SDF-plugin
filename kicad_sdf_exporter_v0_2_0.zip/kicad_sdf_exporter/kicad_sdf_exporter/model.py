from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Pin:
    name: str
    number: str
    electrical_type: str = "unspecified"
    side: str = "right"
    local_x: float = 0.0
    local_y: float = 0.0
    local_rotation: float = 0.0
    length: float = 2.54
    abs_x: float = 0.0
    abs_y: float = 0.0


@dataclass
class Component:
    ref: str
    value: str
    lib_id: str
    uuid: str
    x: float
    y: float
    rotation: float
    footprint: str = ""
    in_bom: bool = True
    on_board: bool = True
    properties: dict[str, Any] = field(default_factory=dict)
    pins: list[Pin] = field(default_factory=list)


@dataclass
class Label:
    text: str
    x: float
    y: float
    kind: str


@dataclass
class Wire:
    points: list[tuple[float, float]]


@dataclass
class Net:
    name: str
    pins: list[str] = field(default_factory=list)
    labels: list[dict[str, Any]] = field(default_factory=list)
    points: list[tuple[float, float]] = field(default_factory=list)


@dataclass
class Design:
    source: str
    components: list[Component]
    wires: list[Wire]
    labels: list[Label]
    nets: list[Net]
    warnings: list[str] = field(default_factory=list)

