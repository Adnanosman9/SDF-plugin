"""KiCad schematic to SDF/JSON exporter."""

__version__ = "0.2.0"
