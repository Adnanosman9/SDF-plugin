from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from .model import Component, Design, Net


POWER_NETS = {"GND", "GNDA", "GNDD", "VCC", "VDD", "VDDIO", "VBUS", "VIN", "+3V3", "+5V", "+12V", "-12V", "3V3", "5V"}
INTERFACE_TOKENS = {
    "i2c": {"SDA", "SCL"},
    "spi": {"MISO", "MOSI", "SCK", "CLK", "CS"},
    "uart": {"TX", "RX", "RTS", "CTS"},
    "usb": {"USB", "D+", "D-", "DP", "DM", "VBUS"},
    "analog_sensor": {"SENSOR", "ADC", "A0", "A1", "A2", "A3"},
}


def infer_blocks(design: Design) -> dict[str, Any]:
    comps = {comp.ref: comp for comp in design.components}
    nets_by_name = {net.name: net for net in design.nets}
    comp_nets = _component_nets(design)
    categories = {ref: classify_component(comp) for ref, comp in comps.items()}

    blocks: list[dict[str, Any]] = []
    blocks.extend(_power_blocks(design, comps, categories))
    blocks.extend(_decoupling_blocks(design, comps, comp_nets))
    blocks.extend(_pullup_blocks(design, comps, comp_nets, categories))
    blocks.extend(_interface_blocks(design, comps, comp_nets, categories))
    blocks.extend(_connector_blocks(design, comps, comp_nets))
    blocks.extend(_core_component_blocks(design, comps, comp_nets, categories))

    deduped = _annotate_quality(_dedupe_blocks(blocks), design.warnings)
    return {
        "schema_version": "0.1",
        "purpose": "functional circuit blocks for AI schematic training",
        "component_categories": categories,
        "blocks": deduped,
        "training_notes": [
            "Use blocks to learn reusable circuit patterns across project types.",
            "Use nets/components for exact electrical structure.",
            "Warnings in metadata identify examples that may need schematic cleanup before training.",
        ],
        "summary": {
            "component_count": len(design.components),
            "net_count": len(design.nets),
            "block_count": len(deduped),
            "clean_block_count": len([block for block in deduped if block["quality"]["status"] == "clean"]),
            "warning_block_count": len([block for block in deduped if block["quality"]["status"] == "warning"]),
            "interfaces": sorted(_detected_interfaces(nets_by_name)),
        },
    }


def classify_component(comp: Component) -> str:
    text = f"{comp.ref} {comp.value} {comp.lib_id} {comp.footprint}".upper()
    ref = comp.ref.upper()
    if ref.startswith("R"):
        return "resistor"
    if ref.startswith("C"):
        return "capacitor"
    if ref.startswith("L"):
        return "inductor"
    if ref.startswith("D"):
        return "diode"
    if ref.startswith(("J", "P", "CONN")) or "CONNECTOR" in text:
        return "connector"
    if "MCU" in text or "ESP32" in text or "STM32" in text or "RP2040" in text or "ATMEGA" in text or "XIAO" in text:
        return "microcontroller"
    if "SENSOR" in text or "MPU" in text or "IMU" in text or "ACCEL" in text or "GYRO" in text:
        return "sensor"
    if "REGULATOR" in text or "LDO" in text or "BUCK" in text or "BOOST" in text:
        return "voltage_regulator"
    if ref.startswith("U"):
        return "integrated_circuit"
    return "misc"


def _component_nets(design: Design) -> dict[str, set[str]]:
    result: dict[str, set[str]] = defaultdict(set)
    for net in design.nets:
        for pin_id in net.pins:
            ref, _, _pin = pin_id.partition(".")
            result[ref].add(net.name)
    return result


def _power_blocks(design: Design, comps: dict[str, Component], categories: dict[str, str]) -> list[dict[str, Any]]:
    blocks = []
    for net in design.nets:
        if not _is_power_net(net.name):
            continue
        refs = sorted(_refs_on_net(net))
        blocks.append(
            {
                "id": f"power_net_{_slug(net.name)}",
                "type": "power_distribution",
                "role": f"Distributes {net.name} to connected components",
                "components": refs,
                "nets": [net.name],
                "signals": [],
                "evidence": {"pins": net.pins, "labels": net.labels},
                "rules": [
                    "Power nets should connect to matching power pins and local bypass capacitors.",
                    "Power symbols are net anchors, not BOM components.",
                ],
            }
        )
    return blocks


def _decoupling_blocks(design: Design, comps: dict[str, Component], comp_nets: dict[str, set[str]]) -> list[dict[str, Any]]:
    blocks = []
    for comp in comps.values():
        if classify_component(comp) != "capacitor":
            continue
        nets = sorted(comp_nets.get(comp.ref, set()))
        if len(nets) < 2 or not any(_is_ground(net) for net in nets) or not any(_is_power_net(net) and not _is_ground(net) for net in nets):
            continue
        nearby = _nearby_refs(comp, comps, exclude={comp.ref}, categories={"microcontroller", "sensor", "integrated_circuit", "voltage_regulator"})
        blocks.append(
            {
                "id": f"decoupling_{comp.ref}",
                "type": "decoupling_capacitor",
                "role": "Stabilizes a local power rail for an IC or module",
                "components": [comp.ref] + nearby[:2],
                "nets": nets,
                "signals": [],
                "evidence": {"capacitor": comp.ref, "nearby_active_components": nearby[:2]},
                "rules": [
                    "A decoupling capacitor is usually connected between a power rail and ground.",
                    "Place decoupling capacitors close to the IC power pins.",
                ],
            }
        )
    return blocks


def _pullup_blocks(
    design: Design,
    comps: dict[str, Component],
    comp_nets: dict[str, set[str]],
    categories: dict[str, str],
) -> list[dict[str, Any]]:
    blocks = []
    for comp in comps.values():
        if categories.get(comp.ref) != "resistor":
            continue
        nets = sorted(comp_nets.get(comp.ref, set()))
        if len(nets) != 2:
            continue
        power = [net for net in nets if _is_power_net(net) and not _is_ground(net)]
        signal = [net for net in nets if not _is_power_net(net)]
        if not power or not signal:
            continue
        signal_net = signal[0]
        interface = _interface_for_net(signal_net)
        blocks.append(
            {
                "id": f"pullup_{comp.ref}_{_slug(signal_net)}",
                "type": "pullup_resistor",
                "role": f"Pulls {signal_net} toward {power[0]}",
                "components": [comp.ref],
                "nets": nets,
                "signals": [signal_net],
                "interfaces": [interface] if interface else [],
                "evidence": {"resistor": comp.ref, "value": comp.value, "power_net": power[0], "signal_net": signal_net},
                "rules": [
                    "Pullup resistors connect a signal line to a positive rail.",
                    "I2C SDA/SCL commonly use pullup resistors.",
                ],
            }
        )
    return blocks


def _interface_blocks(
    design: Design,
    comps: dict[str, Component],
    comp_nets: dict[str, set[str]],
    categories: dict[str, str],
) -> list[dict[str, Any]]:
    groups: dict[str, set[str]] = defaultdict(set)
    for net in design.nets:
        interface = _interface_for_net(net.name)
        if interface:
            groups[interface].add(net.name)

    blocks = []
    for interface, nets in sorted(groups.items()):
        refs = set()
        for ref, ref_nets in comp_nets.items():
            if ref_nets & nets:
                refs.add(ref)
        if not refs:
            continue
        role = {
            "i2c": "Two-wire digital peripheral interface",
            "spi": "Serial peripheral interface",
            "uart": "Asynchronous serial interface",
            "usb": "USB data or power interface",
            "analog_sensor": "Analog or labeled sensor input interface",
        }.get(interface, "Signal interface")
        blocks.append(
            {
                "id": f"interface_{interface}_{_slug('_'.join(sorted(nets)))}",
                "type": f"{interface}_interface",
                "role": role,
                "components": sorted(refs),
                "component_roles": {ref: categories.get(ref, "misc") for ref in sorted(refs)},
                "nets": sorted(nets),
                "signals": sorted(nets),
                "evidence": {"net_names": sorted(nets)},
                "rules": _interface_rules(interface),
            }
        )
    return blocks


def _connector_blocks(design: Design, comps: dict[str, Component], comp_nets: dict[str, set[str]]) -> list[dict[str, Any]]:
    blocks = []
    for comp in comps.values():
        if classify_component(comp) != "connector":
            continue
        nets = sorted(comp_nets.get(comp.ref, set()))
        blocks.append(
            {
                "id": f"connector_{comp.ref}",
                "type": "external_connector",
                "role": "Exposes internal nets to external wiring or modules",
                "components": [comp.ref],
                "nets": nets,
                "signals": [net for net in nets if not _is_power_net(net)],
                "evidence": {"connector": comp.ref, "pin_count": len(comp.pins)},
                "rules": [
                    "Connectors usually expose power, ground, and one or more signals.",
                    "Connector pin labels should match the intended external interface.",
                ],
            }
        )
    return blocks


def _core_component_blocks(
    design: Design,
    comps: dict[str, Component],
    comp_nets: dict[str, set[str]],
    categories: dict[str, str],
) -> list[dict[str, Any]]:
    blocks = []
    for comp in comps.values():
        category = categories.get(comp.ref, "misc")
        if category not in {"microcontroller", "sensor", "voltage_regulator", "integrated_circuit"}:
            continue
        nets = sorted(comp_nets.get(comp.ref, set()))
        blocks.append(
            {
                "id": f"{category}_{comp.ref}",
                "type": category,
                "role": _component_role(category),
                "components": [comp.ref],
                "nets": nets,
                "signals": [net for net in nets if not _is_power_net(net)],
                "evidence": {"value": comp.value, "lib_id": comp.lib_id, "footprint": comp.footprint},
                "rules": _component_rules(category),
            }
        )
    return blocks


def _refs_on_net(net: Net) -> set[str]:
    return {pin.split(".", 1)[0] for pin in net.pins if "." in pin}


def _is_power_net(name: str) -> bool:
    upper = name.upper()
    return upper in POWER_NETS or upper.startswith("+") or upper.startswith("VCC") or upper.startswith("VDD")


def _is_ground(name: str) -> bool:
    return name.upper() in {"GND", "GNDA", "GNDD", "AGND", "DGND"}


def _interface_for_net(name: str) -> str:
    upper = name.upper()
    for interface, tokens in INTERFACE_TOKENS.items():
        if any(token in upper for token in tokens):
            return interface
    return ""


def _detected_interfaces(nets_by_name: dict[str, Net]) -> set[str]:
    return {interface for name in nets_by_name for interface in [_interface_for_net(name)] if interface}


def _nearby_refs(
    comp: Component,
    comps: dict[str, Component],
    exclude: set[str],
    categories: set[str],
) -> list[str]:
    distances = []
    for other in comps.values():
        if other.ref in exclude or classify_component(other) not in categories:
            continue
        dist = ((comp.x - other.x) ** 2 + (comp.y - other.y) ** 2) ** 0.5
        distances.append((dist, other.ref))
    return [ref for _dist, ref in sorted(distances)]


def _interface_rules(interface: str) -> list[str]:
    if interface == "i2c":
        return [
            "I2C uses SDA and SCL between a controller and one or more peripherals.",
            "SDA and SCL generally need pullup resistors to the logic rail.",
            "All devices on the bus must share compatible logic voltage and ground.",
        ]
    if interface == "spi":
        return [
            "SPI uses SCK, MOSI, MISO, and one chip-select per peripheral.",
            "SPI nets should connect controller pins to compatible peripheral pins.",
        ]
    if interface == "uart":
        return [
            "UART TX usually connects to RX on the other device, and RX to TX.",
            "UART devices must share compatible logic voltage and ground.",
        ]
    if interface == "usb":
        return [
            "USB data pairs should keep D+ and D- together.",
            "USB-C designs may need CC resistors and ESD protection.",
        ]
    if interface == "analog_sensor":
        return [
            "Analog sensor nets commonly connect a sensor or divider to an MCU ADC-capable pin.",
            "Sensor inputs may require biasing, filtering, or protection depending on the sensor.",
        ]
    return ["Interface nets should connect pins with compatible electrical roles."]


def _component_role(category: str) -> str:
    return {
        "microcontroller": "Main controller or programmable processing element",
        "sensor": "Measures a physical quantity and reports it to the controller",
        "voltage_regulator": "Converts or stabilizes a power rail",
        "integrated_circuit": "Functional IC block",
    }.get(category, "Circuit component")


def _component_rules(category: str) -> list[str]:
    if category == "microcontroller":
        return [
            "Microcontrollers need valid power and ground connections.",
            "Programming/debug, reset, boot, clock, and decoupling requirements depend on the part.",
            "Peripheral pins should be matched to the intended interface.",
        ]
    if category == "sensor":
        return [
            "Sensors need power, ground, and a compatible signal interface.",
            "Digital sensors often use I2C, SPI, UART, or interrupt pins.",
            "Local decoupling is usually required near the sensor power pins.",
        ]
    if category == "voltage_regulator":
        return [
            "Regulators need input, output, ground, and stability capacitors as required by the datasheet.",
            "Current rating and thermal limits must match the load.",
        ]
    return ["IC pins should be connected according to datasheet requirements."]


def _dedupe_blocks(blocks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen = set()
    out = []
    for block in blocks:
        key = block["id"]
        if key in seen:
            continue
        seen.add(key)
        out.append(block)
    return out


def _annotate_quality(blocks: list[dict[str, Any]], warnings: list[str]) -> list[dict[str, Any]]:
    for block in blocks:
        related = []
        block_nets = set(block.get("nets", []))
        block_components = set(block.get("components", []))
        for warning in warnings:
            if _warning_mentions_net(warning, block_nets) or _warning_mentions_component(warning, block_components):
                related.append(warning)
        block["quality"] = {
            "status": "warning" if related else "clean",
            "warnings": related,
            "use_for_training": not related,
        }
    return blocks


def _warning_mentions_net(warning: str, nets: set[str]) -> bool:
    match = re.match(r"Net\s+(\S+)", warning)
    return bool(match and match.group(1) in nets)


def _warning_mentions_component(warning: str, components: set[str]) -> bool:
    match = re.match(r"Component\s+(\S+)", warning)
    return bool(match and match.group(1) in components)


def _slug(text: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_").lower()
    return slug or "unnamed"
