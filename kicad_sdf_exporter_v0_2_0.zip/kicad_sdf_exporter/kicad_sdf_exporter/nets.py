from __future__ import annotations

from collections import defaultdict

from .geometry import key
from .model import Design, Net


class UnionFind:
    def __init__(self) -> None:
        self.parent: dict[tuple[int, int], tuple[int, int]] = {}

    def add(self, item: tuple[int, int]) -> None:
        self.parent.setdefault(item, item)

    def find(self, item: tuple[int, int]) -> tuple[int, int]:
        self.add(item)
        root = item
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[item] != item:
            nxt = self.parent[item]
            self.parent[item] = root
            item = nxt
        return root

    def union(self, a: tuple[int, int], b: tuple[int, int]) -> None:
        ra = self.find(a)
        rb = self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def resolve_nets(design: Design, tolerance: float = 0.05) -> Design:
    uf = UnionFind()
    point_lookup: dict[tuple[int, int], tuple[float, float]] = {}
    segments: list[tuple[tuple[float, float], tuple[float, float]]] = []

    def add_point(pt: tuple[float, float]) -> tuple[int, int]:
        k = key(pt, tolerance)
        uf.add(k)
        point_lookup.setdefault(k, pt)
        return k

    for wire in design.wires:
        last_key = None
        last_point = None
        for pt in wire.points:
            current_key = add_point(pt)
            if last_key is not None:
                uf.union(last_key, current_key)
            if last_point is not None:
                segments.append((last_point, pt))
            last_key = current_key
            last_point = pt

    pin_members: dict[tuple[int, int], list[str]] = defaultdict(list)
    for comp in design.components:
        for pin in comp.pins:
            if pin.electrical_type == "no_connect":
                continue
            k = add_point((pin.abs_x, pin.abs_y))
            pin_members[k].append(f"{comp.ref}.{pin.name or pin.number}")

    label_members: dict[tuple[int, int], list[dict[str, object]]] = defaultdict(list)
    labels_by_text: dict[str, list[tuple[int, int]]] = defaultdict(list)
    for label in design.labels:
        k = add_point((label.x, label.y))
        label_members[k].append({"text": label.text, "kind": label.kind, "x": label.x, "y": label.y})
        labels_by_text[label.text].append(k)

    for start, end in segments:
        start_key = add_point(start)
        end_key = add_point(end)
        for point_key, point in list(point_lookup.items()):
            if _on_segment(point, start, end, tolerance):
                uf.union(start_key, point_key)
                uf.union(point_key, end_key)

    for keys in labels_by_text.values():
        if not keys:
            continue
        first = keys[0]
        for other in keys[1:]:
            uf.union(first, other)

    grouped_pins: dict[tuple[int, int], set[str]] = defaultdict(set)
    grouped_labels: dict[tuple[int, int], list[dict[str, object]]] = defaultdict(list)
    grouped_points: dict[tuple[int, int], set[tuple[float, float]]] = defaultdict(set)

    for k, pins in pin_members.items():
        root = uf.find(k)
        grouped_pins[root].update(pins)
        grouped_points[root].add(point_lookup[k])
    for k, labels in label_members.items():
        root = uf.find(k)
        grouped_labels[root].extend(labels)
        grouped_points[root].add(point_lookup[k])
    for k, pt in point_lookup.items():
        grouped_points[uf.find(k)].add(pt)

    nets: list[Net] = []
    unnamed_index = 1
    all_roots = set(grouped_pins) | set(grouped_labels)
    for root in sorted(all_roots):
        pins = sorted(grouped_pins.get(root, set()))
        labels = grouped_labels.get(root, [])
        if not pins and not labels:
            continue
        if not labels and len(pins) < 2:
            continue
        name = _net_name(labels, unnamed_index)
        if name.startswith("N$"):
            unnamed_index += 1
        nets.append(Net(name=name, pins=pins, labels=labels, points=sorted(grouped_points.get(root, set()))))

    design.nets = nets
    _add_training_warnings(design)
    return design


def _net_name(labels: list[dict[str, object]], fallback_index: int) -> str:
    texts = sorted({str(label.get("text", "")) for label in labels if str(label.get("text", "")).strip()})
    return texts[0] if texts else f"N${fallback_index}"


def _add_training_warnings(design: Design) -> None:
    connected_refs = {pin.split(".", 1)[0] for net in design.nets for pin in net.pins}
    for comp in design.components:
        if comp.pins and comp.ref not in connected_refs:
            design.warnings.append(f"Component {comp.ref} has pins but no resolved nets")

    for net in design.nets:
        label_count = len(net.labels)
        if label_count >= 2 and len(net.pins) < 2:
            design.warnings.append(
                f"Net {net.name} has {label_count} same-name labels but only {len(net.pins)} resolved component pin(s)"
            )
        _warn_name_pin_mismatch(design, net)


def _warn_name_pin_mismatch(design: Design, net: Net) -> None:
    name = net.name.upper()
    pin_names = [pin.split(".", 1)[1].upper() for pin in net.pins if "." in pin]
    tokens = [token for token in ("SDA", "SCL", "MISO", "MOSI", "SCK", "TX", "RX") if token in name]
    for token in tokens:
        if pin_names and not any(token in pin for pin in pin_names):
            design.warnings.append(f"Net {net.name} name suggests {token}, but resolved pins are {', '.join(net.pins)}")


def _on_segment(
    point: tuple[float, float],
    start: tuple[float, float],
    end: tuple[float, float],
    tolerance: float,
) -> bool:
    px, py = point
    x1, y1 = start
    x2, y2 = end
    min_x, max_x = sorted((x1, x2))
    min_y, max_y = sorted((y1, y2))
    if px < min_x - tolerance or px > max_x + tolerance:
        return False
    if py < min_y - tolerance or py > max_y + tolerance:
        return False
    dx = x2 - x1
    dy = y2 - y1
    if abs(dx) <= tolerance and abs(px - x1) <= tolerance:
        return True
    if abs(dy) <= tolerance and abs(py - y1) <= tolerance:
        return True
    cross = abs((px - x1) * dy - (py - y1) * dx)
    length = (dx * dx + dy * dy) ** 0.5
    return length > 0 and cross / length <= tolerance
