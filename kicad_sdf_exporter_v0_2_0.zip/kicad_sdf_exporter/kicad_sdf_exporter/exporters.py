from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from . import __version__
from .blocks import infer_blocks
from .model import Component, Design, Pin


def write_design_package(design: Design, out_dir: str | Path) -> dict[str, Path]:
    output = Path(out_dir)
    output.mkdir(parents=True, exist_ok=True)

    files = {
        "schematic": output / "schematic.sdf",
        "components": output / "components.json",
        "nets": output / "nets.json",
        "bom": output / "bom.json",
        "blocks": output / "blocks.json",
        "metadata": output / "metadata.json",
        "package": output / "design_package.json",
    }

    sdf = to_sdf(design)
    components = components_json(design)
    nets = nets_json(design)
    bom = bom_json(design)
    blocks = infer_blocks(design)
    metadata = metadata_json(design)
    package = {
        "metadata": metadata,
        "sdf": sdf,
        "components": components,
        "nets": nets,
        "bom": bom,
        "blocks": blocks,
    }

    files["schematic"].write_text(sdf, encoding="utf-8")
    _write_json(files["components"], components)
    _write_json(files["nets"], nets)
    _write_json(files["bom"], bom)
    _write_json(files["blocks"], blocks)
    _write_json(files["metadata"], metadata)
    _write_json(files["package"], package)
    return files


def to_sdf(design: Design) -> str:
    lines: list[str] = [f"SCHEMATIC {Path(design.source).stem}", "", "COMPONENTS:"]
    for comp in sorted(design.components, key=lambda c: _ref_sort(c.ref)):
        lines.append(
            f"  {comp.ref} type={_quote(comp.lib_id)} value={_quote(comp.value)} "
            f"footprint={_quote(comp.footprint)} at=@{comp.x:.3f},{comp.y:.3f} rot={comp.rotation:.1f}"
        )
        for pin in comp.pins:
            lines.append(
                f"    PIN {_quote(pin.name or pin.number)} number={_quote(pin.number)} "
                f"side={pin.side} etype={pin.electrical_type}"
            )

    lines.extend(["", "NETS:"])
    for net in sorted(design.nets, key=lambda n: n.name):
        lines.append(f"  NET {_quote(net.name)}")
        for pin_id in net.pins:
            lines.append(f"    {pin_id} -> NET:{net.name}")

    lines.extend(["", "LABELS:"])
    for label in design.labels:
        lines.append(f"  {label.kind} {_quote(label.text)} at=@{label.x:.3f},{label.y:.3f}")

    lines.extend(["", "WIRES:"])
    for wire in design.wires:
        pts = " ".join(f"@{x:.3f},{y:.3f}" for x, y in wire.points)
        lines.append(f"  WIRE {pts}")
    lines.append("")
    return "\n".join(lines)


def components_json(design: Design) -> list[dict[str, Any]]:
    return [_component_to_dict(comp) for comp in sorted(design.components, key=lambda c: _ref_sort(c.ref))]


def nets_json(design: Design) -> list[dict[str, Any]]:
    return [
        {
            "name": net.name,
            "pins": net.pins,
            "labels": net.labels,
            "points": [{"x": x, "y": y} for x, y in net.points],
        }
        for net in sorted(design.nets, key=lambda n: n.name)
    ]


def bom_json(design: Design) -> list[dict[str, Any]]:
    rows = []
    for comp in sorted(design.components, key=lambda c: _ref_sort(c.ref)):
        if not comp.in_bom:
            continue
        rows.append(
            {
                "ref": comp.ref,
                "value": comp.value,
                "lib_id": comp.lib_id,
                "footprint": comp.footprint,
                "manufacturer_part_number": comp.properties.get("MPN", ""),
                "manufacturer": comp.properties.get("Manufacturer", ""),
                "supplier": comp.properties.get("Supplier", ""),
                "supplier_part_number": comp.properties.get("Supplier Part Number", ""),
                "on_board": comp.on_board,
            }
        )
    return rows


def metadata_json(design: Design) -> dict[str, Any]:
    return {
        "exporter": "kicad_sdf_exporter",
        "version": __version__,
        "source": design.source,
        "units": "millimeters",
        "component_count": len(design.components),
        "net_count": len(design.nets),
        "wire_count": len(design.wires),
        "label_count": len(design.labels),
        "training_quality": "needs_review" if design.warnings else "clean",
        "clean_for_training": not bool(design.warnings),
        "warnings": design.warnings,
    }


def _component_to_dict(comp: Component) -> dict[str, Any]:
    return {
        "ref": comp.ref,
        "value": comp.value,
        "lib_id": comp.lib_id,
        "uuid": comp.uuid,
        "footprint": comp.footprint,
        "position": {"x": comp.x, "y": comp.y, "rotation": comp.rotation},
        "in_bom": comp.in_bom,
        "on_board": comp.on_board,
        "properties": comp.properties,
        "pins": [_pin_to_dict(pin) for pin in comp.pins],
    }


def _pin_to_dict(pin: Pin) -> dict[str, Any]:
    return {
        "name": pin.name,
        "number": pin.number,
        "electrical_type": pin.electrical_type,
        "side": pin.side,
        "local": {"x": pin.local_x, "y": pin.local_y, "rotation": pin.local_rotation, "length": pin.length},
        "absolute_tip": {"x": pin.abs_x, "y": pin.abs_y},
    }


def _write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _quote(value: object) -> str:
    text = str(value or "")
    if not text:
        return '""'
    if any(ch.isspace() for ch in text) or any(ch in text for ch in '"=:'):
        return json.dumps(text)
    return text


def _ref_sort(ref: str) -> tuple[str, int, str]:
    prefix = "".join(ch for ch in ref if not ch.isdigit())
    digits = "".join(ch for ch in ref if ch.isdigit())
    return prefix, int(digits or 0), ref
