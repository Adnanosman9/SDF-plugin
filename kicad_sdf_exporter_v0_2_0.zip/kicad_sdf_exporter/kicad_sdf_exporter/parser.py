from __future__ import annotations

from pathlib import Path
from typing import Any

from .geometry import pin_side, pin_tip, rotate_point
from .model import Component, Design, Label, Pin, Wire
from .sexpr import SExpr, child, children, head, parse, value_after


def parse_kicad_schematic(path: str | Path) -> Design:
    source = Path(path)
    root = parse(source.read_text(encoding="utf-8"))
    lib_pins = _parse_lib_symbols(root)
    components = _parse_components(root, lib_pins)
    components, power_labels = _extract_power_symbols(components)
    wires = _parse_wires(root)
    labels = _parse_labels(root) + power_labels
    return Design(source=str(source), components=components, wires=wires, labels=labels, nets=[])


def _parse_lib_symbols(root: SExpr) -> dict[str, list[Pin]]:
    result: dict[str, list[Pin]] = {}
    lib_symbols = child(root, "lib_symbols")
    if not lib_symbols:
        return result
    for sym in children(lib_symbols, "symbol"):
        if len(sym) < 2:
            continue
        lib_id = str(sym[1])
        pins = _collect_symbol_pins(sym)
        if pins:
            result[lib_id] = pins
    return result


def _collect_symbol_pins(symbol: SExpr) -> list[Pin]:
    pins: list[Pin] = []
    stack = [symbol]
    while stack:
        expr = stack.pop()
        for item in expr:
            if not isinstance(item, list):
                continue
            if head(item) == "pin":
                pins.append(_parse_pin(item))
            elif head(item) == "symbol":
                stack.append(item)
    return pins


def _parse_pin(expr: SExpr) -> Pin:
    electrical_type = str(expr[1]) if len(expr) > 1 else "unspecified"
    at = child(expr, "at") or ["at", 0.0, 0.0, 0.0]
    length = float(value_after(expr, "length", 2.54) or 2.54)
    name_expr = child(expr, "name")
    number_expr = child(expr, "number")
    name = str(name_expr[1]) if name_expr and len(name_expr) > 1 else ""
    number = str(number_expr[1]) if number_expr and len(number_expr) > 1 else ""
    rotation = float(at[3]) if len(at) > 3 else 0.0
    return Pin(
        name=name or number,
        number=number or name,
        electrical_type=electrical_type,
        side=pin_side(rotation),
        local_x=float(at[1]),
        local_y=float(at[2]),
        local_rotation=rotation,
        length=length,
    )


def _parse_components(root: SExpr, lib_pins: dict[str, list[Pin]]) -> list[Component]:
    components: list[Component] = []
    for sym in children(root, "symbol"):
        lib_id = str(sym[1]) if len(sym) > 1 and not isinstance(sym[1], list) else str(value_after(sym, "lib_id", ""))
        at = child(sym, "at") or ["at", 0.0, 0.0, 0.0]
        props = _parse_properties(sym)
        ref = str(props.get("Reference", ""))
        value = str(props.get("Value", ""))
        if not ref or ref.startswith("#"):
            ref = value or lib_id.split(":")[-1]
        uuid = str(value_after(sym, "uuid", ""))
        rotation = float(at[3]) if len(at) > 3 else 0.0
        comp = Component(
            ref=ref,
            value=value,
            lib_id=lib_id,
            uuid=uuid,
            x=float(at[1]),
            y=float(at[2]),
            rotation=rotation,
            footprint=str(props.get("Footprint", "")),
            in_bom=_yes_no(value_after(sym, "in_bom", "yes")),
            on_board=_yes_no(value_after(sym, "on_board", "yes")),
            properties=props,
        )
        comp.pins = _absolute_pins(comp, lib_pins.get(lib_id, []))
        components.append(comp)
    return components


def _absolute_pins(component: Component, pins: list[Pin]) -> list[Pin]:
    out: list[Pin] = []
    for pin in pins:
        # In KiCad schematic symbols, the pin's local `(at x y rot)` is the
        # electrical connection point. `length` describes the drawn body-facing
        # pin line and must not be added to the net anchor.
        rx, ry = rotate_point(pin.local_x, pin.local_y, component.rotation)
        total_rotation = (pin.local_rotation + component.rotation) % 360
        out.append(
            Pin(
                name=pin.name,
                number=pin.number,
                electrical_type=pin.electrical_type,
                side=pin_side(total_rotation),
                local_x=pin.local_x,
                local_y=pin.local_y,
                local_rotation=pin.local_rotation,
                length=pin.length,
                abs_x=component.x + rx,
                abs_y=component.y + ry,
            )
        )
    return out


def _extract_power_symbols(components: list[Component]) -> tuple[list[Component], list[Label]]:
    normal: list[Component] = []
    labels: list[Label] = []
    for comp in components:
        if not _is_power_symbol(comp):
            normal.append(comp)
            continue
        net_name = comp.value or comp.lib_id.split(":")[-1] or comp.ref
        if comp.pins:
            pin = comp.pins[0]
            labels.append(Label(text=net_name, x=pin.abs_x, y=pin.abs_y, kind="power"))
        else:
            labels.append(Label(text=net_name, x=comp.x, y=comp.y, kind="power"))
    return normal, labels


def _is_power_symbol(comp: Component) -> bool:
    ref = str(comp.properties.get("Reference", comp.ref))
    return comp.lib_id.startswith("power:") or ref.startswith("#PWR")


def _parse_properties(sym: SExpr) -> dict[str, Any]:
    props: dict[str, Any] = {}
    for prop in children(sym, "property"):
        if len(prop) >= 3:
            props[str(prop[1])] = prop[2]
    return props


def _parse_wires(root: SExpr) -> list[Wire]:
    wires: list[Wire] = []
    for wire in children(root, "wire"):
        pts = child(wire, "pts")
        if not pts:
            continue
        points = []
        for xy in children(pts, "xy"):
            if len(xy) >= 3:
                points.append((float(xy[1]), float(xy[2])))
        if len(points) >= 2:
            wires.append(Wire(points=points))
    return wires


def _parse_labels(root: SExpr) -> list[Label]:
    labels: list[Label] = []
    for kind in ("label", "global_label", "hierarchical_label"):
        for expr in children(root, kind):
            if len(expr) < 2:
                continue
            at = child(expr, "at")
            if not at or len(at) < 3:
                continue
            labels.append(Label(text=str(expr[1]), x=float(at[1]), y=float(at[2]), kind=kind))
    return labels


def _yes_no(value: object) -> bool:
    return str(value).lower() not in ("no", "false", "0")
